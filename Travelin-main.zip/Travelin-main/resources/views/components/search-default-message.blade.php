<div class="m-0 py-3 px-2">
    <div class="alert alert-info text-center shadow-sm" role="alert">
        Gunakan kotak pencarian di atas untuk menemukan tempat yang kamu inginkan.
    </div>
</div>
